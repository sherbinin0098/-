package ru.proverka.avto;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.speech.RecognizerIntent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {

    static final String HOME = "https://sherbinin0098.github.io/proverka/";
    static final String HOST = "sherbinin0098.github.io";
    static final int REQ_FILE = 11;
    static final int REQ_LOC = 12;
    static final int REQ_SPEECH = 13;
    static final int REQ_AUTH = 14;

    WebView web;
    ValueCallback<Uri[]> filePending;
    Uri cameraUri;
    GeolocationPermissions.Callback geoCb;
    String geoOrigin;
    TextRecognizer recognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // temporary files from previous runs (camera shots, shared files, unfinished saves)
        clearDir(new File(getCacheDir(), "shots"));
        clearDir(new File(getCacheDir(), "share"));
        clearDir(new File(getCacheDir(), "out"));
        getWindow().setStatusBarColor(Color.parseColor("#1f5bc4"));

        web = new WebView(this);
        setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);
        s.setSupportMultipleWindows(false);

        web.addJavascriptInterface(new Bridge(), "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost()) || "file".equals(u.getScheme())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // no app can open it
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadUrl("file:///android_asset/offline.html");
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePending != null) {
                    filePending.onReceiveValue(null);
                }
                filePending = callback;
                cameraUri = null;

                boolean image = false;
                String[] types = params.getAcceptTypes();
                if (types != null) {
                    for (String t : types) {
                        if (t != null && t.startsWith("image")) {
                            image = true;
                        }
                    }
                }

                Intent cam = null;
                if (image) {
                    try {
                        File dir = new File(getCacheDir(), "shots");
                        dir.mkdirs();
                        File f = File.createTempFile("cam", ".jpg", dir);
                        cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                        cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception e) {
                        cam = null;
                        cameraUri = null;
                    }
                }

                Intent launch;
                if (cam != null && params.isCaptureEnabled()) {
                    launch = cam;
                } else {
                    launch = Intent.createChooser(params.createIntent(), null);
                    if (cam != null) {
                        launch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                    }
                }
                try {
                    startActivityForResult(launch, REQ_FILE);
                } catch (Exception e) {
                    filePending = null;
                    callback.onReceiveValue(null);
                    return true;
                }
                return true;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    geoCb = callback;
                    geoOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
                }
            }
        });

        web.loadUrl(HOME);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePending == null) {
                return;
            }
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data != null && (data.getData() != null || data.getClipData() != null)) {
                    result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                } else if (cameraUri != null) {
                    result = new Uri[]{cameraUri};
                }
            }
            filePending.onReceiveValue(result);
            filePending = null;
            cameraUri = null;
            return;
        }
        if (requestCode == REQ_AUTH) {
            try {
                AuthorizationResult r = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);
                authJs(r.getAccessToken(), r.getAccessToken() == null ? "cancel" : null);
            } catch (Exception e) {
                authJs(null, "cancel");
            }
            return;
        }
        if (requestCode == REQ_SPEECH) {
            ArrayList<String> heard = null;
            if (resultCode == RESULT_OK && data != null) {
                heard = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            }
            callJs("window.__speech&&window.__speech(" + (heard == null ? "[]" : new JSONArray(heard).toString()) + ")");
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    void authJs(String token, String err) {
        callJs("window.__gauth&&window.__gauth(" + (token == null ? "null" : JSONObject.quote(token)) + "," + (err == null ? "null" : JSONObject.quote(err)) + ")");
    }

    // Google account: access to the app's own files on Google Drive (drive.file)
    void driveAuthorize(final boolean interactive) {
        try {
            AuthorizationRequest req = AuthorizationRequest.builder()
                    .setRequestedScopes(Arrays.asList(new Scope("https://www.googleapis.com/auth/drive.file")))
                    .build();
            Identity.getAuthorizationClient(this).authorize(req)
                    .addOnSuccessListener(new OnSuccessListener<AuthorizationResult>() {
                        @Override
                        public void onSuccess(AuthorizationResult r) {
                            if (r.hasResolution()) {
                                if (!interactive || r.getPendingIntent() == null) {
                                    authJs(null, "need");
                                    return;
                                }
                                try {
                                    startIntentSenderForResult(r.getPendingIntent().getIntentSender(), REQ_AUTH, null, 0, 0, 0);
                                } catch (Exception e) {
                                    authJs(null, "ui");
                                }
                            } else {
                                authJs(r.getAccessToken(), r.getAccessToken() == null ? "auth" : null);
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(Exception e) {
                            authJs(null, "auth " + e.getMessage());
                        }
                    });
        } catch (Exception e) {
            authJs(null, "auth");
        }
    }

    void callJs(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(code, null);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_LOC && geoCb != null) {
            boolean ok = false;
            for (int g : grantResults) {
                if (g == PackageManager.PERMISSION_GRANTED) {
                    ok = true;
                }
            }
            geoCb.invoke(geoOrigin, ok, false);
            geoCb = null;
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        web.evaluateJavascript("window.__theme&&window.__theme()", null);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){try{return window.__back?window.__back():false}catch(e){return false}})()", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if ("true".equals(value)) {
                    return;
                }
                moveTaskToBack(true);
            }
        });
    }

    static void clearDir(File dir) {
        File[] list = dir.listFiles();
        if (list == null) {
            return;
        }
        for (File f : list) {
            f.delete();
        }
    }

    boolean saveToDownloads(InputStream in, String name, String mime) {
        return saveToMedia(in, name, mime, false);
    }

    // photo = true: Pictures/Проверка авто, visible in the gallery
    boolean saveToMedia(InputStream in, String name, String mime, boolean photo) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(name));
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, photo ? Environment.DIRECTORY_PICTURES + "/Проверка авто" : Environment.DIRECTORY_DOWNLOADS);
            Uri u = getContentResolver().insert(photo ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) {
                return false;
            }
            OutputStream o = getContentResolver().openOutputStream(u);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                o.write(buf, 0, n);
            }
            o.close();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try {
                in.close();
            } catch (Exception ignored) {
                // nothing
            }
        }
    }

    boolean shareFile(File f, String mime) {
        try {
            final Uri u = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            final Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, u);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startActivity(Intent.createChooser(send, "Отправить"));
                }
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static String safeName(String name) {
        String n = name == null ? "file" : name.replace('/', '_').replace('\\', '_').trim();
        return n.isEmpty() ? "file" : n;
    }

    class Bridge {
        @JavascriptInterface
        public boolean isDark() {
            int m = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            return m == Configuration.UI_MODE_NIGHT_YES;
        }

        @JavascriptInterface
        public boolean save(String name, String mime, String b64) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                return saveToDownloads(new java.io.ByteArrayInputStream(bytes), name, mime);
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean share(String name, String mime, String b64) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "share");
                dir.mkdirs();
                File f = new File(dir, safeName(name));
                FileOutputStream o = new FileOutputStream(f);
                o.write(bytes);
                o.close();
                return shareFile(f, mime);
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean driveAuth(final boolean interactive) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    driveAuthorize(interactive);
                }
            });
            return true;
        }

        // voice: system speech recognition, answer goes to window.__speech([...])
        @JavascriptInterface
        public boolean listen() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
                        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите номер машины");
                        startActivityForResult(i, REQ_SPEECH);
                    } catch (Exception e) {
                        callJs("window.__speech&&window.__speech([])");
                    }
                }
            });
            return true;
        }

        // text on a photo (ML Kit, on the phone, no internet); answer goes to window.__ocr(req, [{t,x,y,w,h}])
        @JavascriptInterface
        public boolean ocr(String id, final String req) {
            File f = parts.remove(id);
            names.remove(id);
            if (f == null) {
                return false;
            }
            try {
                Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath());
                f.delete();
                if (bmp == null) {
                    return false;
                }
                if (recognizer == null) {
                    recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                }
                final String q = JSONObject.quote(req);
                recognizer.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener(new OnSuccessListener<Text>() {
                            @Override
                            public void onSuccess(Text text) {
                                JSONArray arr = new JSONArray();
                                try {
                                    for (Text.TextBlock b : text.getTextBlocks()) {
                                        for (Text.Line l : b.getLines()) {
                                            JSONObject o = new JSONObject();
                                            o.put("t", l.getText());
                                            Rect r = l.getBoundingBox();
                                            if (r != null) {
                                                o.put("x", r.left);
                                                o.put("y", r.top);
                                                o.put("w", r.width());
                                                o.put("h", r.height());
                                            }
                                            arr.put(o);
                                        }
                                    }
                                } catch (Exception e) {
                                    // keep what we have
                                }
                                callJs("window.__ocr&&window.__ocr(" + q + "," + arr.toString() + ")");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(Exception e) {
                                callJs("window.__ocr&&window.__ocr(" + q + ",null)");
                            }
                        });
                return true;
            } catch (Exception e) {
                f.delete();
                return false;
            }
        }

        // big files come in pieces: fileStart -> fileChunk ... -> fileEnd
        final ConcurrentHashMap<String, File> parts = new ConcurrentHashMap<>();
        final ConcurrentHashMap<String, String> names = new ConcurrentHashMap<>();

        @JavascriptInterface
        public String fileStart(String name) {
            try {
                File dir = new File(getCacheDir(), "out");
                dir.mkdirs();
                String id = Long.toString(System.nanoTime());
                File f = new File(dir, id + ".part");
                new FileOutputStream(f).close();
                parts.put(id, f);
                names.put(id, safeName(name));
                return id;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean fileChunk(String id, String b64) {
            File f = parts.get(id);
            if (f == null) {
                return false;
            }
            try {
                FileOutputStream o = new FileOutputStream(f, true);
                o.write(Base64.decode(b64, Base64.DEFAULT));
                o.close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean fileEnd(String id, String mime, String mode) {
            File f = parts.remove(id);
            String name = names.remove(id);
            if (f == null || name == null) {
                return false;
            }
            try {
                if ("share".equals(mode)) {
                    File dir = new File(getCacheDir(), "share");
                    dir.mkdirs();
                    File dst = new File(dir, name);
                    dst.delete();
                    if (!f.renameTo(dst)) {
                        return false;
                    }
                    return shareFile(dst, mime);
                }
                boolean ok = saveToMedia(new FileInputStream(f), name, mime, "photo".equals(mode));
                f.delete();
                return ok;
            } catch (Exception e) {
                f.delete();
                return false;
            }
        }
    }
}
